package pl.kalisz.egzamin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    boolean stanOdkurzacza = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button zatwierdz = findViewById(R.id.zatwierdz);
        zatwierdz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText poleEdycyjne = findViewById(R.id.numerPrania);
                String text = poleEdycyjne.getText().toString();
                TextView message = findViewById(R.id.message);
                try{
                    int numerProgramu = Integer.parseInt(text);
                    if(numerProgramu>=1 && numerProgramu<=12){
                        message.setText("Numer prania: "+numerProgramu);
                    }

                }catch (NumberFormatException ex){
                    message.setText("Numer prania: nie podano");
                }
            }
        });
        Button wlacz = findViewById(R.id.on);
        wlacz.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView odkurzaczKomunikat = findViewById(R.id.odkurzaczKomunikat);
                if(!stanOdkurzacza){
                    wlacz.setText("Wyłącz");
                    odkurzaczKomunikat.setText("Odkurzacz włączony");
                    stanOdkurzacza = true;
                }else{
                    wlacz.setText("Włącz");
                    odkurzaczKomunikat.setText("Odkurzacz wyłączony");
                    stanOdkurzacza = false;
                }

            }
        });
    }
}