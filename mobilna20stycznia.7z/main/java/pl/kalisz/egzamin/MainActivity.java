package pl.kalisz.egzamin;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<Kosc> kosci = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        Button button = (Button) findViewById(R.id.button);
        ImageView image1 = (ImageView) findViewById(R.id.image1);
        ImageView image2 = (ImageView) findViewById(R.id.image2);
        ImageView image3 = (ImageView) findViewById(R.id.image3);
        ImageView image4 = (ImageView) findViewById(R.id.image4);
        ImageView image5 = (ImageView) findViewById(R.id.image5);
        TextView sumaText = (TextView) findViewById(R.id.textView);
        button.setOnClickListener(v->{
            Kosc k1 = new Kosc();
            image1. setImageResource(getResource(k1.liczbaOczek));
            kosci.add(k1);
            Kosc k2 = new Kosc();
            image2. setImageResource(getResource(k2.liczbaOczek));
            kosci.add(k2);
            Kosc k3 = new Kosc();
            image3. setImageResource(getResource(k3.liczbaOczek));
            kosci.add(k3);
            Kosc k4 = new Kosc();
            image4. setImageResource(getResource(k4.liczbaOczek));
            kosci.add(k4);
            Kosc k5 = new Kosc();
            image5. setImageResource(getResource(k5.liczbaOczek));
            kosci.add(k5);
            int suma = k1.liczbaOczek + k2.liczbaOczek + k3.liczbaOczek + + k4.liczbaOczek + k5.liczbaOczek;
            sumaText.setText(String.valueOf(suma));

        });
        image1.setOnClickListener(v->{
            if(!kosci.isEmpty()){
                Kosc kosc = kosci.get(0);
                if(kosc.dostepna){
                    image1.setImageAlpha(128);
                    kosc.dostepna = false;
                }else{
                    kosc.dostepna = true;
                    image1.setImageAlpha(255);
                }
            }
        });
        image2.setOnClickListener(v->{
            if(!kosci.isEmpty()){
                Kosc kosc = kosci.get(1);
                if(kosc.dostepna){
                    image2.setImageAlpha(128);
                    kosc.dostepna = false;
                }else{
                    kosc.dostepna = true;
                    image2.setImageAlpha(255);
                }
            }
        });
        image3.setOnClickListener(v->{
            if(!kosci.isEmpty()){
                Kosc kosc = kosci.get(2);
                if(kosc.dostepna){
                    image3.setImageAlpha(128);
                    kosc.dostepna = false;
                }else{
                    kosc.dostepna = true;
                    image3.setImageAlpha(255);
                }
            }
        });
        image4.setOnClickListener(v->{
            if(!kosci.isEmpty()){
                Kosc kosc = kosci.get(3);
                if(kosc.dostepna){
                    image4.setImageAlpha(128);
                    kosc.dostepna = false;
                }else{
                    kosc.dostepna = true;
                    image4.setImageAlpha(255);
                }
            }
        });
        image5.setOnClickListener(v->{
            if(!kosci.isEmpty()){
                Kosc kosc = kosci.get(4);
                if(kosc.dostepna){
                    image5.setImageAlpha(128);
                    kosc.dostepna = false;
                }else{
                    kosc.dostepna = true;
                    image5.setImageAlpha(255);
                }
            }
        });
    }
    private int getResource(int liczbaOczek){
        switch (liczbaOczek){
            case 1: return R.drawable.kosc1;
            case 2: return R.drawable.kosc2;
            case 3: return R.drawable.kosc3;
            case 4: return R.drawable.kosc4;
            case 5: return R.drawable.kosc5;
            case 6: return R.drawable.kosc6;
            default: return R.drawable.kosc0;
        }
    }
}