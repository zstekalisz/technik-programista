import { Component, ElementRef, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  started = false;

  @ViewChild('naszeVideo')
  element !: ElementRef<HTMLVideoElement>

  dajesz() {
    let videoEl = this.element.nativeElement;
    if (videoEl.paused) {
      videoEl.play();
      this.started = true;
    }
  }
  pauza() {
    let video = this.element.nativeElement;
    if(!video.paused){
      video.pause();
    }else if(this.started){
      video.play();
    }
  }

  playOrStop(event: Event) {
    let videoElement = event.target as HTMLVideoElement;
    if (!videoElement.paused) {
      videoElement.pause();
    } else {
      videoElement.play();
    }
  }
  title = 'Video';
}
