package pl.kalisz.zste.egzamin;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class KoscTest {

	@Test
	void testRzut() {
		Kosc kosc = new Kosc(0);
		kosc.rzut();
		assertTrue(kosc.liczbaOczek>0&& kosc.liczbaOczek<7);
		int liczbaOczek = kosc.liczbaOczek;
		kosc.zablokuj();
		kosc.rzut();
		assertEquals(liczbaOczek, kosc.liczbaOczek);
		kosc.rzut();
		assertEquals(liczbaOczek, kosc.liczbaOczek);
		kosc.rzut();
		assertEquals(liczbaOczek, kosc.liczbaOczek);
	}

}
