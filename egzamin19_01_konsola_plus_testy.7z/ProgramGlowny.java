package pl.kalisz.zste.egzamin;

import java.util.Scanner;

public class ProgramGlowny {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Podaj liczbę oczek od 1 do 6");
		int liczba = s.nextInt();
		s.close();
		Kosc kosc1 = new Kosc(liczba);
		System.out.println("Liczba instancji " +Kosc.liczbaInstancji);
		System.out.println("Liczba wyrzuconych oczek : "+kosc1.liczbaOczek+ " "+kosc1.getText());
		System.out.println("Nazwa pliku : "+ kosc1.nazwyPlikow.get(kosc1.idPliku));
		Kosc kosc2 = new Kosc();
		System.out.println("Liczba instancji " + Kosc.liczbaInstancji);
		System.out.println("Liczba wyrzuconych oczek : "+kosc2.liczbaOczek+ " "+kosc2.getText());
		System.out.println("Nazwa pliku : "+ kosc2.nazwyPlikow.get(kosc2.idPliku));
		
		
	}

}
