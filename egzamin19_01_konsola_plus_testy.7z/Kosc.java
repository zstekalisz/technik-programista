package pl.kalisz.zste.egzamin;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Kosc {

	public static int liczbaInstancji = 0;
	public List<String> nazwyPlikow = Arrays.asList("kosc0.png", "kosc1.png", "kosc2.png", "kosc3.png", 
			"kosc4.png", "kosc5.png", "kosc6.png");
	public int liczbaOczek;
	public int idPliku;
	public boolean dostepna;
	
	public Kosc(int liczbaOczek) {
		if(liczbaOczek<1 || liczbaOczek>6) {
			this.liczbaOczek = 0;
			this.idPliku = 0;
			this.dostepna = true;
		}else {
			this.liczbaOczek = liczbaOczek;
			this.idPliku = liczbaOczek;
			this.dostepna = true;
		}
		liczbaInstancji++;
		
	}
	public Kosc() {
		Random random = new Random();
		int losowa = random.nextInt(6);
		losowa++;
		this.liczbaOczek = losowa;
		this.idPliku = losowa;
		this.dostepna = true;
		liczbaInstancji++;
		
	}
	
	public void rzut() {
		if(this.dostepna) {
			Random random = new Random();
			int losowa = random.nextInt(6);
			losowa++;
			this.liczbaOczek = losowa;
			this.idPliku = losowa;
		}
	}
	public void zablokuj() {
		this.dostepna = false;
	}
	
	public String getText() {
		switch(this.liczbaOczek) {
		case 0: return "zero";
		case 1: return "jeden";
		case 2: return "dwa";
		case 3: return "trzy";
		case 4: return "cztery";
		case 5: return "pięć";
		case 6: return "sześć";
		default : return "zero";
		}
	}
	
	
}
