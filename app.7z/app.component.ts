import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule } from '@angular/forms'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'WalidacjaFormularzygr2';
  bazaAdresowa = new Array<Adres>();
  adres = new Adres();

}

export class Adres{
  miejscowosc?:string;
  ulica?:string;
  numerDomu?:string;
  numerMieszkania?:string;
  kodPocztowy?:string;
  poczta?:string;
  powiat?:string;
  gmina?:string;

}
