package pl.kalisz.zste.egzamin;

public abstract class Pytanie {
	protected String trescPytania;
	protected String plik;
	protected boolean odpowiedz;
	
	public Pytanie(String trescPytania, String plik) {
		this.trescPytania = trescPytania;
		this.plik = plik;
	}
	
	public abstract boolean sprawdz(char odpowiedz);

}
