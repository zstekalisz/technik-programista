import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { FormsModule, NgForm } from '@angular/forms'

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, FormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {

  title = 'WalidacjaFormularzy';
  bazaAdresow = new Array<Adres>();
  adres = new Adres();
  check = false;
  
  zapisz(form:NgForm) {
    if(form.valid){
      this.bazaAdresow.push(this.adres);
      this.adres = new Adres();
      this.check = false;
    }else{
      this.check = true;
    }
    
  }
}

export class Adres {
  miejscowosc?: string;
  ulica?: string;
  kodPocztowy?: string;
  numerDomu?: string;
  numerMieszkania?: string;
  poczta?: string;

  constructor() {

  }

}
