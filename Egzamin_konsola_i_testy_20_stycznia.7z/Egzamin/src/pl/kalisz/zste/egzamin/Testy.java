package pl.kalisz.zste.egzamin;

import java.util.Scanner;

public class Testy {

	public static void main(String[] args) {
		//new Pytanie("test", "test.zip"); //klasa obstrakcyjna nie można utworzyć instancji
		Scanner sc = new Scanner(System.in);
		System.out.println("Podaj treść pytania:");
		String pytanie = sc.nextLine();
		System.out.println("Podaj nazwę pliku:");
		String plik = sc.nextLine();
		System.out.println("Podaj odpowiedź A:");
		String odpowiedz1 = sc.nextLine();
		System.out.println("Podaj odpowiedź B:");
		String odpowiedz2 = sc.nextLine();
		System.out.println("Podaj odpowiedź C:");
		String odpowiedz3 = sc.nextLine();
		System.out.println("Podaj prawidłową odpowiedź (A, B, lub C:");
		String prawidlowa = sc.nextLine();
		PytanieZamkniete pytanieZamkniete = new PytanieZamkniete(pytanie, plik, 
				odpowiedz1, odpowiedz2, odpowiedz3, prawidlowa.charAt(0));
		System.out.println("Odpowiedz na pytanie wpisz A, B lub C");
		String udzielonaOdpowiedz = sc.nextLine();
		boolean sprawdz = pytanieZamkniete.sprawdz(udzielonaOdpowiedz.charAt(0));
		if(sprawdz) {
			System.out.println("Odpowiedź prawidłowa");
		}else {
			System.out.println("Odpowiedź nieprawidłowa");
		}

	}

}
