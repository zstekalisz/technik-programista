package pl.kalisz.zste.egzamin;

public class PytanieZamkniete extends Pytanie{
	
	private String odpowiedz1;
	private String odpowiedz2;
	private String odpowiedz3;
	private char odpowiedzZnak;
	
	

	public PytanieZamkniete(String trescPytania, String plik, String odpowiedz1, String odpowiedz2, String odpowiedz3,
			char odpowiedzZnak) {
		super(trescPytania, plik);
		this.odpowiedz1 = odpowiedz1;
		this.odpowiedz2 = odpowiedz2;
		this.odpowiedz3 = odpowiedz3;
		this.odpowiedzZnak = odpowiedzZnak;
	}


	@Override
	public boolean sprawdz(char odpowiedz) {
		if(odpowiedz==this.odpowiedzZnak) {
			this.odpowiedz = true;
			return true;
		}
		this.odpowiedz = false;
		return false;
	}

}
